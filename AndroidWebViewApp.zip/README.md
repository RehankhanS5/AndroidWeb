# Android WebView App

This is a basic Android application that loads a website inside a WebView.

## Features
- Load any URL in WebView
- JavaScript enabled

## Setup
1. Open in Android Studio.
2. Replace `https://www.example.com` with your desired URL.
3. Run on emulator or real device.